var mysql = require('mysql2');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin",
  database: "loja"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM pet", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
  });
});